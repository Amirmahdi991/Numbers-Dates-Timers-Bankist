import PageTitle from "../components/PageTitle";

export default function Profile() {
    return (
        <div className="h-full flex flex-col">
            <PageTitle title="Profile" />
        </div>
    );
}
