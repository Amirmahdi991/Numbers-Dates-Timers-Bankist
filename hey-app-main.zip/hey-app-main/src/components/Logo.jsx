import React from "react";

export default function Logo() {
    return <h3 className={`text-2xl font-extrabold text-teal-500`}>Hey 👋</h3>;
}
