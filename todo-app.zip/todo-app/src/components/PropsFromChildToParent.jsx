import Parent from "./child-to-parent/Parent";

export default function PropsFromChildToParent() {
    return <Parent />;
}
