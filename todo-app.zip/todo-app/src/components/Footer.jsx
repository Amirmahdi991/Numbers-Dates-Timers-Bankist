function Footer() {
    return (
        <footer>
            <h1>App Footer</h1>
        </footer>
    );
}

export default Footer;
